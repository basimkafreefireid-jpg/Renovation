RENOVATION & HANDYMAN — WEBSITE PACKAGE

Files:
- index.html: complete responsive website (CSS and JavaScript are embedded)
- images/: images supplied with the project, renamed to consistent paths

How to use:
1. Upload index.html and the entire images folder to the same hosting/repository root.
2. Keep the folder name exactly "images".
3. Test the deployed site on desktop and mobile.
4. Replace the sample/inspiration portfolio images with permission-cleared photos of actual completed work when available.
5. Verify the business name, phone, email, service area, and structured data before publishing.

Important:
- "60 Hz" is a display refresh rate. A website cannot force a screen to run at 60 Hz. This site uses lightweight CSS transitions and requestAnimationFrame for scroll UI updates; actual smoothness depends on the device, browser, display, and system load.
- SEO cannot guarantee a #1 ranking. Results depend on competition, business details, site authority, reviews, and search engine evaluation.
- No canonical URL is included because the live website domain was not supplied.
